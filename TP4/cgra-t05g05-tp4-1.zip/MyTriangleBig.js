import {CGFobject} from '../lib/CGF.js';
/**
 * MyTriangleBig
 * @constructor
 * @param scene - Reference to MyScene object
 */
export class MyTriangleBig extends CGFobject {
	constructor(scene, id) {
		super(scene);

        this.id = id;

		this.initBuffers();
	}
	
	initBuffers() {
		this.vertices = [
			-2, 0, 0, //0
			2, 0, 0, //1
			0, 2, 0, //2
		];

        //Counter-clockwise reference of vertices
		this.indices = [
			0, 1, 2, 
		];

		this.normals = [
			0, 0, 1,
			0, 0, 1,
			0, 0, 1,
		];

        if(this.id == 1) {  // Blue triangle
            this.texCoords = [
                0.00, 0.00, //0
                1.00, 0.00, //2
                0.50, 0.50  //1
            ];

        } else if(this.id == 2) {   // Orange triangle
            this.texCoords = [
                1.00, 1.00, //1
                0.50, 0.50, //2
                1.00, 0.00  //3
            ];
        }

		//The defined indices (and corresponding vertices)
		//will be read in groups of three to draw triangles
		this.primitiveType = this.scene.gl.TRIANGLES;

		this.initGLBuffers();
	}

    draw(tangram){
        if(this.id == 1) {  // Blue triangle
            var ang = Math.PI/4;

            tangram.scene.pushMatrix();
            tangram.scene.rotate(-ang, 0, 0, 1);
    
            tangram.triangleBig1.display();
    
            tangram.scene.popMatrix();
        } else if (this.id == 2) {  // Orange triangle
            var ang = Math.PI/2;
            var sqrt_2 = Math.sqrt(2);
    
            tangram.scene.pushMatrix();
            tangram.scene.translate(sqrt_2, -2 + sqrt_2, 0);
            tangram.scene.rotate(-ang, 0, 0, 1);
    
            tangram.triangleBig2.display();
    
            tangram.scene.popMatrix();
        }

    }
}

