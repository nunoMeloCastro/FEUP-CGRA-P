import {CGFappearance, CGFobject} from '../lib/CGF.js';
import { MyDiamond } from "./MyDiamond.js";
import { MyTriangle } from "./MyTriangle.js";
import { MyTriangleBig } from "./MyTriangleBig.js";
import { MyTriangleSmall } from "./MyTriangleSmall.js";
import { MyParallelogram } from "./MyParallelogram.js";
/**
 * MyTangram
 * @constructor
 * @param scene - Reference to MyScene object
 */
export class MyTangram extends CGFobject {
    constructor(scene) {
        super(scene);
        // Initialize Parallelogram
        this.diamond = new MyDiamond(scene);

        // Initialize Triangle
        this.triangle = new MyTriangle(scene);

        //Initialize Triangle Big
        this.triangleBig1 = new MyTriangleBig(scene, 1);
        this.triangleBig2 = new MyTriangleBig(scene, 2);

        // Initializes Triangle Small 
        this.triangleSmall1 = new MyTriangleSmall(scene, 1);
        this.triangleSmall2 = new MyTriangleSmall(scene, 2);

        // Initialize Parallelogram
        this.parallelogram = new MyParallelogram(scene);

        this.scene = scene;

        this.material = new CGFappearance(scene);
        this.material.setAmbient(0.1, 0.1, 0.1, 1.0);
        this.material.setDiffuse(0.9, 0.9, 0.9, 1.0);
        this.material.setSpecular(1.0, 1.0, 1.0, 1.0);
        this.material.setShininess(10.0);
        this.material.loadTexture('images/tangram.png');
        this.material.setTextureWrap('REPEAT', 'REPEAT'); 
    }

    display() {
        this.material.apply();
        this.diamond.draw(this);

        // Purple triangle
        this.triangleSmall1.draw(this); 

        // Red trianggle
        this.triangleSmall2.draw(this);

        // Blue trianggle
        this.triangleBig1.draw(this);

        // Orange triangle
        this.triangleBig2.draw(this);
        this.triangle.draw(this);
        this.parallelogram.draw(this);
    }
}

