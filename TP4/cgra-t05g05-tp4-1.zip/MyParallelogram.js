import {CGFobject} from '../lib/CGF.js';
/**
 * MyParallelogram
 * @constructor
 * @param scene - Reference to MyScene object
 */
export class MyParallelogram extends CGFobject {
	constructor(scene) {
		super(scene);
		this.initBuffers();
	}
	
	initBuffers() {
		this.vertices = [
            0, 0, 0, //0
			1, 1, 0, //1
			2, 0, 0, //2
			3, 1, 0, //3
		];

        //Counter-clockwise reference of vertices
		this.indices = [
			0, 1, 2, 
			3, 2, 1,
		];

		this.normals = [
			0, 0, 1,
			0, 0, 1,
			0, 0, 1,
			0, 0, 1,
		];

        this.texCoords = [
            1.00, 1.00, //0
            0.75, 0.75, //1
            0.50, 1.00, //2
            0.25, 0.75  //3
        ];

		//The defined indices (and corresponding vertices)
		//will be read in groups of three to draw triangles
		this.primitiveType = this.scene.gl.TRIANGLES;

		this.initGLBuffers();
	}

	draw(tangram){
		var ang = 3*Math.PI/8;
		var sqrt_2 =  Math.sqrt(2);

		tangram.scene.pushMatrix();
		tangram.scene.translate(2 + sqrt_2, -2 + sqrt_2, 0);
		tangram.scene.rotate(-ang, 0, 0, 1);
		tangram.scene.scale(1, -1, 1);
		
	
		tangram.parallelogram.display();
	
		tangram.scene.popMatrix();

	}
}
