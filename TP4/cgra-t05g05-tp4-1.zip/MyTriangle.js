import {CGFobject} from '../lib/CGF.js';
/**
 * MyTriangle
 * @constructor
 * @param scene - Reference to MyScene object
 */
export class MyTriangle extends CGFobject {
	constructor(scene) {
		super(scene);
		this.initBuffers();
	}
	
	initBuffers() {
		this.vertices = [
			-Math.sqrt(2), 0, 0, //0
			0, Math.sqrt(2), 0,	//1
			Math.sqrt(2), 0, 0,	//2
		];

		//Counter-clockwise reference of vertices
		this.indices = [
			0, 2, 1, 
		];

		this.normals = [
			0, 0, 1, //0
			0, 0, 1, //1
			0, 0, 1, //2
		];

        this.texCoords = [
            0.00, 0.50, //0
            0.00, 1.00, //1
            0.50, 1.00  //2
        ];

		//The defined indices (and corresponding vertices)
		//will be read in groups of three to draw triangles
		this.primitiveType = this.scene.gl.TRIANGLES;

		this.initGLBuffers();
	}

	draw(tangram){
		var sqrt_2 = Math.sqrt(2);

		tangram.scene.pushMatrix();
		tangram.scene.translate(0, 2*sqrt_2, 0);
	
		tangram.triangle.display();
	
		tangram.scene.popMatrix();
	}
}

