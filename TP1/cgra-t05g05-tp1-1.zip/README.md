# CGRA 2020/2021

## Group T05G05

## TP 1 Notes

- In exercise 1 we initially observed that our objects were being display always in green whenever we used a checkbox. However, we realized that this was because we put our display according to the checkbox status before the function *setDefaultAppearence*. After changing our code to the correct section, we were able to successfully complete the exercise.
- In exercise 2, since we had already managed to detect and correct our previous error, we managed to get everything that was asked in the exercise without any difficulty.
